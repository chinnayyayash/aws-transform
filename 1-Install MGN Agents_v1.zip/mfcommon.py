#  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#  SPDX-License-Identifier: Apache-2.0

import sys
import re
import requests
import json
import getpass
import boto3
import botocore
import base64
import calendar
import time
import subprocess
import csv
import logging
from collections import namedtuple

ts = calendar.timegm(time.gmtime())
# Constants referenced from other modules.
api_stage = 'prod'

serverendpoint = '/user/server'
databaseendpoint = '/user/database'
appendpoint = '/user/app'
waveendpoint = '/user/wave'
REQUESTS_DEFAULT_TIMEOUT = 60

PREFIX_CREDENTIALS_STORE = 'cached_secret:'
ERROR_MSG_PREFIX = "ERROR:"
credentials_store = {}

logging.basicConfig(format='%(asctime)s | %(levelname)s | %(message)s', level=logging.ERROR)  # //NOSONAR Basic configuration doesn't pose security risk
logger = logging.getLogger()
logger.setLevel(logging.ERROR)


# Attempt to open the configuration file, if not present most likely this is a Lambda invocation so config override used.
try:
    with open('FactoryEndpoints.json') as json_file:
        mf_config = json.load(json_file)
except FileNotFoundError:
    mf_config = None

# start of the external interface / functions to be called by clients ###############

def get_mf_config_user_api_id():
    # Function required to maintain backward compatibility with pre-3.3.1 CMF deployments,
    # allowing newer scripts to work on older versions.
    if "UserApi" in mf_config:
        return mf_config["UserApi"]
    elif "UserApiUrl" in mf_config:
        return extract_api_id_from_url(mf_config["UserApiUrl"])
    else:
        print(f"{ERROR_MSG_PREFIX} Invalid FactoryEndpoints.json file. UserApi or UserApiUrl not present.")
        sys.exit()


def extract_api_id_from_url(api_url):
    if api_url:
        return api_url[8:18]


def get_api_endpoint_headers(token):
    return {"Authorization": token}


def get_api_endpoint_url(api_id, api_endpoint, mf_config_override=None):

    if mf_config_override:
        local_mf_config = mf_config_override
    else:
        local_mf_config = mf_config

    if 'VpceId' in local_mf_config and local_mf_config['VpceId'] != '':
        return f'https://{api_id}-{local_mf_config["VpceId"]}.execute-api.{local_mf_config["Region"]}.amazonaws.com/{api_stage}{api_endpoint}'
    else:
        return f'https://{api_id}.execute-api.{local_mf_config["Region"]}.amazonaws.com/{api_stage}{api_endpoint}'


def build_requests_parameters(token, api_id, api_path, mf_config_override=None):
    return {
        "url": get_api_endpoint_url(api_id, api_path, mf_config_override),
        "headers": get_api_endpoint_headers(token),
        "timeout": REQUESTS_DEFAULT_TIMEOUT
    }


def get_data_from_api(token, api_id, api_path, mf_config_override=None):
    request_parameters = build_requests_parameters(token, api_id, api_path, mf_config_override)

    try:
        requests_response = requests.get(**request_parameters)  # nosec B113
    except requests.exceptions.ConnectionError:
        msg = f'{ERROR_MSG_PREFIX} Could not connect to API endpoint {request_parameters["url"]}{api_path}.'
        print(msg)
        sys.exit()

    if requests_response.status_code != 200:
        msg = f'{ERROR_MSG_PREFIX} Bad response from API {request_parameters["url"]}{api_path}. {requests_response.text}'
        print(msg)
        sys.exit()

    return requests_response


def post_data_to_api(token, api_id, api_path, payload, mf_config_override=None):
    request_parameters = build_requests_parameters(token, api_id, api_path, mf_config_override)
    request_parameters['data'] = json.dumps(payload)

    try:
        requests_response = requests.post(**request_parameters)  # nosec B113

    except requests.exceptions.ConnectionError:
        msg = f'{ERROR_MSG_PREFIX} Could not connect to API endpoint {request_parameters["url"]}.'
        print(msg)
        sys.exit()

    if requests_response.status_code != 200:
        msg = f'{ERROR_MSG_PREFIX} Bad response from API {request_parameters["url"]}. {requests_response.text}'
        print(msg)

    return requests_response


def put_data_to_api(token, api_id, api_path, payload, mf_config_override=None):
    request_parameters = build_requests_parameters(token, api_id, api_path, mf_config_override)
    request_parameters['data'] = json.dumps(payload)

    try:
        requests_response = requests.put(**request_parameters)  # nosec B113

    except requests.exceptions.ConnectionError:
        msg = f'{ERROR_MSG_PREFIX} Could not connect to API endpoint {request_parameters["url"]}{api_path}.'
        print(msg)
        sys.exit()

    if requests_response.status_code != 200:
        msg = f'{ERROR_MSG_PREFIX} Bad response from API {request_parameters["url"]}{api_path}. {requests_response.text}'
        print(msg)

    return requests_response


def factory_login(silent=False, mf_config_override=None):
    if mf_config_override:
        local_mf_config = mf_config_override
    else:
        local_mf_config = mf_config

    login_data, username, using_secret = get_cmf_user_login_data(local_mf_config)
    token = validate_cmf_user_login(local_mf_config, login_data, username, using_secret, silent=silent)

    return token


def get_server_credentials(
    local_username, local_password, server, secret_override=None, no_user_prompts=False):
    secret_name = ""

    # Local account details passed, do not get from secrets manager.
    if local_username != "" and local_password != "":
        return {'username': local_username, 'password': local_password}

    if "secret_name" in server and server['secret_name'] != "":
        secret_name = server['secret_name']
        print("Server specific secret configured, using: " + secret_name)
    elif secret_override is not None:
        secret_name = secret_override

    if secret_name != "":

        # Check if already read secret, and if so return cached.
        cached_credential = return_cached_secret(secret_name)
        if cached_credential is not None:
            return cached_credential

        mfauth = get_server_credentials_with_secret(
            secret_name, server, no_user_prompts, mf_config)
        return mfauth

    if server['server_os_family'].lower() == "windows":
        credential = get_windows_server_credentials(no_user_prompts)
        if credential is not None:
            return credential

    if server['server_os_family'].lower() == "linux":
        credential = get_linux_server_credentials(no_user_prompts)
        if credential is not None:
            return credential

    if no_user_prompts == True:
        print(
            "No credentials supplied by user or specified in Migration "
            "Factory server secret attribute. Returning blank username and password")
        return {'username': '', 'password': '', 'private_key': False}


def get_credentials(secret_name, no_user_prompts=True, not_found_response=None):
    if secret_name != "":

        # Check if already read secret, and if so return cached.
        cached_credential = return_cached_secret(secret_name)
        if cached_credential is not None:
            return cached_credential

        return get_credentials_with_secret(secret_name, no_user_prompts, mf_config)

    # return default not found response.
    return not_found_response


def filter_items(items, key, filter=None):
    """Filter items by key value or array intersection.
    
    Args:
        items: List of dictionaries to filter
        key: Dictionary key to filter on
        filter: Value or list to filter by. If both filter and item[key] are lists, 
               keeps items with intersecting values
    
    Returns:
        Filtered list of items
    """
    if not filter:
        return items
    
    filtered_items = []
    for item in items:
        if key not in item or item[key] is None:
            continue
            
        item_value = item[key]
        
        if isinstance(filter, list):
            # Check if item value matches any value in filter list
            if isinstance(item_value, list):
                if bool(set(item_value) & set(filter)):
                    filtered_items.append(item)
            elif item_value in filter:
                filtered_items.append(item)
        else:
            # Check if item value matches filter value
            if isinstance(item_value, list):
                if filter in item_value:
                    filtered_items.append(item)
            elif item_value == filter:
                filtered_items.append(item)
    
    return filtered_items


ServerGroupResult = namedtuple('ServerGroupResult', ['aws_accounts', 'linux_exist', 'windows_exist', 'errors'])

def group_servers_by_account(servers, os_split, waveid, log_error = print):
    """Group servers by AWS account and region with OS validation.
    
    Args:
        servers: List of server dictionaries
        os_split: Boolean to split servers by OS type
        waveid: Wave ID for logging purposes
        log_error: Function to call for error logging (default: print)
    
    Returns:
        ServerGroupResult: Named tuple with aws_accounts, linux_exist, windows_exist, errors
    """
    accounts_dict = {}
    linux_exist = False
    windows_exist = False
    
    errors = []
    
    for server in servers:
        if 'aws_accountid' not in server or 'aws_region' not in server:
            continue
            
        if len(str(server['aws_accountid']).strip()) != 12 or not str(server['aws_accountid']).strip().isdigit():
            msg = f"{ERROR_MSG_PREFIX} Incorrect AWS Account Id for server: {server['server_name']}. Must be 12 digits."
            log_error(msg)
            errors.append(msg)
            continue
            
        if 'server_fqdn' not in server:
            msg = f"{ERROR_MSG_PREFIX} server_fqdn for server: {server['server_name']} doesn't exist"
            log_error(msg)
            errors.append(msg)
            continue

        try:
            validate_server_fqdn(server['server_fqdn'])
        except ValueError as e:
            msg = f"{ERROR_MSG_PREFIX} {e}"
            log_error(msg)
            errors.append(msg)
            continue

        account_key = (str(server['aws_accountid']).strip(), server['aws_region'].lower().strip())
        
        if account_key not in accounts_dict:
            account = {
                'aws_accountid': account_key[0],
                'aws_region': account_key[1]
            }
            if os_split:
                account['servers_windows'] = []
                account['servers_linux'] = []
            else:
                account['servers'] = []
            accounts_dict[account_key] = account
            
        account = accounts_dict[account_key]
        
        if os_split:
            if 'server_os_family' not in server:
                msg = f"{ERROR_MSG_PREFIX} server_os_family does not exist for: {server['server_name']}"
                log_error(msg)
                errors.append(msg)
                continue
            
            if server['server_os_family'].lower() == 'windows':
                account['servers_windows'].append(server)
                windows_exist = True
            elif server['server_os_family'].lower() == 'linux':
                account['servers_linux'].append(server)
                linux_exist = True
            else:
                msg = f"{ERROR_MSG_PREFIX} Invalid server_os_family for: {server['server_name']}, please select either Windows or Linux"
                log_error(msg)
                errors.append(msg)
                continue            
        else:
            account['servers'].append(server)
            
    aws_accounts = list(accounts_dict.values())
    
    if len(aws_accounts) == 0:
        msg = f"{ERROR_MSG_PREFIX} server list for wave_id {waveid} is empty"
        log_error(msg)
        errors.append(msg)
        
    if len(errors) > 0:
        return ServerGroupResult([], False, False, errors)
    
    for account in aws_accounts:
        print(f"### Servers in Target Account: {account['aws_accountid']}, "
              f"region: {account['aws_region']} ###")
        
        if os_split:
            for server in account['servers_windows'] + account['servers_linux']:
                print(server['server_fqdn'])
            if len(account['servers_windows']) == 0 and len(account['servers_linux']) == 0:
                print(f"INFORMATIONAL: Server list for wave {waveid} and account: {account['aws_accountid']} "
                      f"region: {account['aws_region']} is empty....")
        else:
            for server in account['servers']:
                print(server['server_fqdn'])
            if len(account['servers']) == 0:
                print(f"INFORMATIONAL: Server list for wave {waveid} and account: {account['aws_accountid']} "
                      f"region: {account['aws_region']} is empty....")
        print("")
    
    return ServerGroupResult(aws_accounts, linux_exist, windows_exist, [])


def get_factory_servers(waveid, token, app_ids=None, server_ids=None, os_split=True, rtype=None):
    """Retrieve and group servers from Migration Factory by criteria from UI where user can specify
    
    Args:
        waveid: Wave ID to filter servers
        token: Authentication token for API access
        app_ids: Optional application IDs to filter servers
        server_ids: Optional server IDs to filter servers
        os_split: Boolean to split servers by OS type (default: True)
        rtype: Optional migration type filter
    
    Returns:
        If os_split=True: tuple of (aws_accounts, linux_exist, windows_exist)
        If os_split=False: aws_accounts list
    """
    try:
        # Get allservers from migration factory
        servers_api_response = get_data_from_api(token, get_mf_config_user_api_id(), serverendpoint)
        cmf_servers = json.loads(servers_api_response.text)

        # As server schema has all the related attributes
        # we can simply filter the list by each criterion  in a row 
        cmf_servers = filter_items(cmf_servers, 'wave_id', waveid)
        cmf_servers = filter_items(cmf_servers, 'app_ids', app_ids)
        cmf_servers = filter_items(cmf_servers, 'server_id', server_ids)
        cmf_servers = filter_items(cmf_servers, 'r_type', rtype)

        servers = sorted(cmf_servers, key=lambda i: i['server_name'])
        
        result = group_servers_by_account(servers, os_split, waveid)
        
        if len(result.errors) > 0:
            print('\n'.join(result.errors))
            sys.exit()

        if os_split:
            return result.aws_accounts, result.linux_exist, result.windows_exist
        else:
            return result.aws_accounts
    except botocore.exceptions.ClientError as error:
        sys_exit = handle_client_error(error)
        if sys_exit:
             sys.exit()


def clean_value(value):
    return value.lower().strip()


# Strict FQDN/hostname regex: labels separated by dots, each label starts and
# ends with alphanumeric, may contain hyphens, max 63 chars per label.
# Also allows bare IPv4 addresses (digits and dots only).
_FQDN_REGEX = re.compile(
    r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?'
    r'(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$'
)


def validate_server_fqdn(fqdn):
    """Validate that fqdn contains only safe hostname/FQDN characters.

    Prevents command injection when server_fqdn is interpolated into
    PowerShell or SSH command strings.

    Raises:
        ValueError: If fqdn contains characters outside [a-zA-Z0-9.-]
    """
    if not fqdn or not _FQDN_REGEX.match(fqdn):
        raise ValueError(
            f"Invalid server_fqdn: {fqdn!r}. "
            "Must be a valid hostname, FQDN, or IPv4 address."
        )


def is_cmf_server_match_for_mgn_ip_address(interface, cmf_server):
    cmf_server_name = clean_value(cmf_server['server_name'])
    cmf_server_fqdn = clean_value(cmf_server['server_fqdn'])

    if interface['isPrimary'] is True:
        for ip_address in interface['ips']:
            if cmf_server_name == clean_value(ip_address) or cmf_server_fqdn == clean_value(ip_address):
                return True

    return False


def is_cmf_server_match_for_mgn_hostname(mgn_source_server, cmf_server):
    cmf_server_name = clean_value(cmf_server['server_name'])
    cmf_server_fqdn = clean_value(cmf_server['server_fqdn'])
    mgn_server_hostname = clean_value(mgn_source_server['sourceProperties']['identificationHints']
                                      .get('hostname', '{notset}'))
    mgn_server_fqdn = clean_value(mgn_source_server['sourceProperties']['identificationHints']
                                  .get('fqdn','{notset}'))

    if cmf_server_name == mgn_server_hostname or cmf_server_name == mgn_server_fqdn \
        or cmf_server_fqdn == mgn_server_hostname or cmf_server_fqdn == mgn_server_fqdn:
        return True

    return False


def is_cmf_server_matching_mgn_source_server(cmf_server, mgn_source_server):
    # Check if any IP addresses in MGN record match with CMF.
    if 'networkInterfaces' in mgn_source_server['sourceProperties']:
        for interface in mgn_source_server['sourceProperties']['networkInterfaces']:
            if is_cmf_server_match_for_mgn_ip_address(interface, cmf_server):
                return True

    if is_cmf_server_match_for_mgn_hostname(mgn_source_server, cmf_server):
        return True

    return False


def get_mgn_source_server(cmf_server, mgn_source_servers):
    found_matching_source_server = None

    for mgn_source_server in mgn_source_servers:
        if 'isArchived' in mgn_source_server and not mgn_source_server['isArchived']:
            # Check if the factory server exist in Application Migration Service

            if is_cmf_server_matching_mgn_source_server(cmf_server, mgn_source_server):
                found_matching_source_server = mgn_source_server

    if found_matching_source_server is not None:
        return found_matching_source_server
    else:
        return None


def execute_cmd(host, username, key, cmd, using_key):
    # Function provides backward compatibility with older scripts, new scripts should call execute_cmd_via_ssh directly.
    return execute_cmd_via_ssh(host, username, key, cmd, using_key, False)


def execute_cmd_via_ssh(host, username, key, cmd, using_key, multi_threaded=False):
    if not sys.warnoptions:
        import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=Warning)
        import paramiko

    # Function provides scripts a standard function to run remote commands against ssh enabled systems.
    output = ''
    error = ''
    ssh = None
    try:
        ssh, error = open_ssh(host, username, key, using_key)
        if ssh:
            stdin, stdout, stderr = ssh.exec_command(cmd)  # nosec B601
            for line in stdout.readlines():
                output = output + line
            for line in stderr.readlines():
                error = error + line
            stdin.close()
    except IOError as io_error:
        error = f"Unable to execute the command {cmd} due to {str(io_error)}"
        if not multi_threaded:
            print(error)
    except paramiko.SSHException as ssh_exception:
        error = f"Unable to execute the command {cmd} due to {str(ssh_exception)}"
        if not multi_threaded:
            print(error)
    finally:
        if ssh is not None:
            ssh.close()
    return output, error


def open_ssh(host, username, key_pwd, using_key, multi_threaded=False):
    if not sys.warnoptions:
        import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=Warning)
        import paramiko

    base_error = f"Unable to connect to host {host} with username {username} due to"
    ssh = None
    error = ''
    try:
        if using_key:
            from io import StringIO
            private_key = paramiko.RSAKey.from_private_key(StringIO(key_pwd.strip()))
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())  # nosec B507
            ssh.connect(hostname=host, username=username, pkey=private_key)
        else:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())  # nosec B507
            ssh.connect(hostname=host, username=username, password=key_pwd)
    except IOError as io_error:
        ssh = None
        error = f"{base_error} {str(io_error)}"
        if not multi_threaded:
            print(error)
    except paramiko.SSHException as ssh_exception:
        ssh = None
        error = f"{base_error} {str(ssh_exception)}"
        if not multi_threaded:
            print(error)
    except Exception as all_other:
        ssh = None
        error = f"{base_error} {str(all_other)}"
        if not multi_threaded:
            print(error)

    return ssh, error


# Function to print the status in csv format.
def create_csv_report(report_name, agent_installed_server_details, wave_id):
    final_report_name_csv = "cmf-" + report_name + "-report_Wave_" + wave_id + ".csv"

    iterator = map(convert_dictionaries_keys_to_list, agent_installed_server_details)
    fields = list(iterator)[0]
    iterator = map(convert_dictionaries_values_to_list, agent_installed_server_details)
    row = list(iterator)

    # Workaround for software service validation report. First row in this report is an unwanted data. This row was
    # generated just to get the dynamic csv header properly.
    if report_name == "serviceValdationReport":
        row.pop(0)

    with open(final_report_name_csv, 'w', newline="") as f:
        # using csv.writer method from CSV package
        write = csv.writer(f)
        write.writerow(fields)
        write.writerows(row)

    print("")
    print("**************************************************************************************************")
    print("Please check the status in the generated report...")
    print("Validation Overview CSV : " + final_report_name_csv)
    return final_report_name_csv


# Function to convert a dictionaries keys into list format required by csv module
def convert_dictionaries_keys_to_list(var):
    return (list(var.keys()))


# Function to convert a dictionaries values into list format required by csv module
def convert_dictionaries_values_to_list(var):
    return (list(var.values()))


def find_distribution(host, username, key_pwd, using_key):
    distribution = "linux"
    output, _ = execute_cmd_via_ssh(host, username, key_pwd, "cat /etc/*release",
                                    using_key)
    if "ubuntu" in output:
        distribution = "ubuntu"
    elif "fedora" in output:
        distribution = "fedora"
    elif "suse" in output:
        distribution = "suse"
    return distribution


def update_server_migration_status(token, server_id, new_status):
    status_update_payload = {"migration_status": new_status}
    return put_data_to_api(token, get_mf_config_user_api_id(), f'{serverendpoint}/{server_id}', status_update_payload)


def update_server_replication_status(token, server_id, new_status):
    status_update_payload = {"replication_status": new_status}
    return put_data_to_api(token, get_mf_config_user_api_id(), f'{serverendpoint}/{server_id}', status_update_payload)


def add_windows_servers_to_trusted_hosts(cmf_servers):
    # Get all servers FQDNs into csv for trusted hosts update.
    trusted_hosts_server_csv = ""
    for server in cmf_servers:
        validate_server_fqdn(server["server_fqdn"])
        trusted_hosts_server_csv = trusted_hosts_server_csv + server["server_fqdn"] + ','

    trusted_hosts_server_csv = trusted_hosts_server_csv[:-1]
    # Add servers to local trusted hosts to allow authentication if different domain.
    subprocess.run([
        "powershell.exe",
        "Set-Item WSMan:\\localhost\\Client\\TrustedHosts",
        "-Value '" + trusted_hosts_server_csv + "'",
        "-Concatenate",
        "-Force"],
        check=True)


# Function is used with new database entity to get databases based on the AWS account they are targeted to and wave.
def get_factory_databases(waveid, token, app_ids=None, database_ids=None, rtype=None):
    try:

        databases_api_response = get_data_from_api(token, get_mf_config_user_api_id(), databaseendpoint)

        databases = json.loads(databases_api_response.text)

        databases = filter_items(databases, 'database_id', database_ids)
        databases = filter_items(databases, 'wave_id', waveid)

        apps_api_response = get_data_from_api(token, get_mf_config_user_api_id(), appendpoint)

        apps = json.loads(apps_api_response.text)

        apps = filter_items(apps, 'app_id', app_ids)

        databases = sorted(databases, key=lambda i: i['database_name'])
        apps = sorted(apps, key=lambda i: i['app_name'])

        # Get Unique target AWS account and region
        aws_accounts = factory_database_accounts_from_apps(apps, waveid)
        # Get database list
        factory_database_extract_databases(aws_accounts, databases, apps, waveid, rtype)
        return aws_accounts
    except botocore.exceptions.ClientError as error:
        if ":" in str(error):
            err = ''
            msgs = str(error).split(":")[1:]
            for msg in msgs:
                err = err + msg
            msg = f"{ERROR_MSG_PREFIX} {err}"
            print(msg)
            sys.exit()
        else:
            msg = f"{ERROR_MSG_PREFIX} {str(error)}"
            print(msg)
            sys.exit()


def factory_database_accounts_from_apps(apps, waveid):
    aws_accounts = []
    for app in apps:
        if is_app_associated_with_wave(app, waveid) and 'aws_accountid' in app and 'aws_region' in app:
            factory_database_update_accounts(app, aws_accounts)
    if len(aws_accounts) == 0:
        msg = f"{ERROR_MSG_PREFIX} Target accounts for wave {waveid} is empty...."
        print(msg)
        sys.exit()

    return aws_accounts


def factory_database_update_accounts(app, aws_accounts):
    if len(str(app['aws_accountid']).strip()) == 12:
        target_account = {}
        target_account['aws_accountid'] = str(app['aws_accountid']).strip()
        target_account['aws_region'] = app['aws_region'].lower().strip()
        target_account['databases'] = []
        if target_account not in aws_accounts:
            aws_accounts.append(target_account)
    else:
        msg = f"{ERROR_MSG_PREFIX} Incorrect AWS Account Id Length for app: {app['app_name']}"
        print(msg)
        sys.exit()


def factory_database_extract_databases(aws_accounts, databases, apps, waveid, rtype):
    for account in aws_accounts:
        print("### Databases in Target Account: " + account['aws_accountid'] + " , region: " + account[
            'aws_region'] + " ###")
        for app in apps:
            if 'aws_accountid' in app and 'aws_region' in app:
                factory_database_match_databases_apps(app, waveid, account, rtype, databases)
        print("")
        if len(account['databases']) == 0:
            msg = (f"{ERROR_MSG_PREFIX} Database list for wave {waveid} and account: {account['aws_accountid']} "
                   f"region: {account['aws_region']} is empty....")
            print(msg)


def factory_database_match_databases_apps(app, waveid, account ,rtype, databases):
    if '_processed_databases' not in account:
        account['_processed_databases'] = set()
    
    if is_app_associated_with_wave(app, waveid):
        if str(app['aws_accountid']).strip() == str(account['aws_accountid']):
            if app['aws_region'].lower().strip() == account['aws_region']:
                for database in databases:
                    if is_asset_associated_with_app(database, app['app_id']):
                        database_id = database.get('database_id', database.get('database_name'))
                        if database_id not in account['_processed_databases']:
                            account['_processed_databases'].add(database_id)
                            factory_database_update_db_attrs(database, account, app, rtype)


def factory_database_update_db_attrs(database, account, app, rtype):
    if (rtype is None) or ('r_type' in database and database['r_type'] == rtype):
        account['databases'].append(database)
        print(database['database_name'])


# end of the external interface / functions to be called by clients ###############

# start of credential related functions ###############

def get_server_credentials_with_secret(secret_name, server, no_user_prompts, mf_config):
    try:
        secret_data = None
        mfauth = None

        secret_data_raw = get_raw_secret_data(mf_config, secret_name)
        secret_data_tmp_json = get_secret_data_tmp_json(secret_data_raw)

        secret_data = {}
        secret_data = get_data_field_from_secret_data_tmp_json(
            "USERNAME", secret_data_tmp_json, secret_data)
        secret_data = get_password_in_secret_data(
            secret_data_tmp_json, secret_data)
        secret_data = get_data_field_from_secret_data_tmp_json(
            "SECRET_TYPE", secret_data_tmp_json, secret_data)
        secret_data = get_data_field_from_secret_data_tmp_json(
            "OS_TYPE", secret_data_tmp_json, secret_data)

        mfauth = get_secret_data(secret_data, secret_name)
        return mfauth
    except botocore.exceptions.ClientError as e:
        print(e)
        handle_credentials_client_error(e, server['secret_name'], no_user_prompts)


def get_credentials_with_secret(secret_name, no_user_prompts, mf_config):
    try:
        secret_data = None
        mfauth = None

        secret_data_raw = get_raw_secret_data(mf_config, secret_name)
        secret_data_tmp_json = get_secret_data_tmp_json(secret_data_raw)

        secret_data = {}
        secret_data = get_data_field_from_secret_data_tmp_json(
            "USERNAME", secret_data_tmp_json, secret_data)
        secret_data = get_password_in_secret_data(
            secret_data_tmp_json, secret_data)
        secret_data = get_data_field_from_secret_data_tmp_json(
            "SECRET_TYPE", secret_data_tmp_json, secret_data)
        secret_data = get_data_field_from_secret_data_tmp_json(
            "SECRET_KEY", secret_data_tmp_json, secret_data)
        secret_data = get_data_field_from_secret_data_tmp_json(
            "SECRET_VALUE", secret_data_tmp_json, secret_data)
        secret_data = get_data_field_from_secret_data_tmp_json(
            "APIKEY", secret_data_tmp_json, secret_data)
        secret_data = get_data_field_from_secret_data_tmp_json(
            "SECRET_STRING", secret_data_tmp_json, secret_data)
        secret_data = get_data_field_from_secret_data_tmp_json(
            "OS_TYPE", secret_data_tmp_json, secret_data)

        mfauth = get_secret_data(secret_data, secret_name)
        return mfauth
    except botocore.exceptions.ClientError as e:
        handle_credentials_client_error(e, secret_name, no_user_prompts)


def return_cached_secret(secret_name):
    # Check if already read secret, and if so return cached.
    if PREFIX_CREDENTIALS_STORE + secret_name in credentials_store:
        return credentials_store[PREFIX_CREDENTIALS_STORE + secret_name]
    return None


def get_raw_secret_data(mf_config, secret_name):
    secretsmanager_client = boto3.client('secretsmanager', mf_config['Region'])
    mf_service_account = secretsmanager_client.get_secret_value(SecretId=secret_name)
    secret_data_raw = mf_service_account['SecretString']

    return secret_data_raw


def get_secret_data_tmp_json(secret_data_raw):
    if secret_data_raw[0] != "{":
        # Secret could be encoded, perform decode.
        secret_data_tmp = base64.b64decode(secret_data_raw.encode("utf-8")).decode("ascii")
        secret_data_tmp_json = json.loads(secret_data_tmp)
    else:
        secret_data_tmp_json = json.loads(secret_data_raw)

    return secret_data_tmp_json


def get_data_field_from_secret_data_tmp_json(
    field_name, secret_data_tmp_json, secret_data):
    field_name_lower_case = field_name.lower()
    secret_data[field_name_lower_case] = ""
    if field_name in secret_data_tmp_json:
        secret_data[field_name_lower_case] = secret_data_tmp_json[field_name]

    return secret_data


def get_password_in_secret_data(secret_data_tmp_json, secret_data):
    secret_data['password'] = ""
    if "PASSWORD" in secret_data_tmp_json:
        if "IS_SSH_KEY" in secret_data_tmp_json and secret_data_tmp_json['IS_SSH_KEY'].lower() == 'true':
            secret_data['password'] = base64.b64decode(secret_data_tmp_json['PASSWORD'].encode("utf-8")) \
                .decode("ascii")
            secret_data['password'] = secret_data['password'].replace('\\n', '\n')
            secret_data['private_key'] = True
        else:
            secret_data['password'] = secret_data_tmp_json['PASSWORD']
            secret_data['private_key'] = False

    return secret_data


def get_secret_data(secret_data, secret_name):
    mfauth = secret_data

    # Cache secret for next server.
    credentials_store[PREFIX_CREDENTIALS_STORE + secret_name] = mfauth

    return mfauth


def handle_credentials_client_error(e, secret_name, no_user_prompts):
    if e.response['Error']['Code'] == 'ResourceNotFoundException' or e.response['Error'][
        'Code'] == 'AccessDeniedException':
        if no_user_prompts:
            print(f"Secret not found [{secret_name}] doesn't exist or access is denied to Secret.")
        else:
            print(f"Secret not found [{secret_name}] doesn't exist or access is denied to Secret, "
                  f"please enter username and password")
    else:
        # Unknown error returned when getting secret.
        print(e.response['Error'])


def get_windows_server_credentials(no_user_prompts):
    if 'windows' in credentials_store:
        return credentials_store['windows']
    if no_user_prompts == False:
        print(get_prompt_message_for_credentials("Windows"))
        username = input("Windows Username (leave blank to use current logged on user): ")
        if username != "":
            password = get_windows_password()
        else:
            password = ""
        store_cred = input(get_input_message_for_credentials("Windows"))
        credentials = {'username': username, 'password': password}
        if 'y' in store_cred.lower():
            credentials_store['windows'] = credentials
        return credentials
    return None


def get_linux_server_credentials(no_user_prompts):
    if 'linux' in credentials_store:
        return credentials_store['linux']
    if no_user_prompts == False:
        print(get_prompt_message_for_credentials("Linux"))
        username, password, key_exist = get_linux_password()
        store_cred = input(get_input_message_for_credentials("Linux"))
        credentials = {'username': username, 'password': password, 'private_key': key_exist}
        if 'y' in store_cred.lower():
            credentials_store['linux'] = credentials
        return credentials
    return None


# common functions
def get_windows_password():
    pass_first = getpass.getpass("Windows User Password: ")
    pass_second = getpass.getpass("Re-enter Password: ")
    while (pass_first != pass_second):
        print("Password mismatch, please try again!")
        pass_first = getpass.getpass("Windows User Password: ")
        pass_second = getpass.getpass("Re-enter Password: ")
    return pass_second


def get_linux_password():
    print("******************************************")
    print("* Enter Linux Sudo username and password *")
    print("******************************************")
    user_name = ''
    pass_key = ''
    has_key = ''
    key_exist = False
    user_name = input("Linux Username: ")
    has_key = input("If you use a private key to login, press [Y] or if use password press [N]: ")
    if 'y' in has_key.lower():
        pass_key = input('Private Key file name: ')
        key_exist = True
    else:
        pass_key_first = getpass.getpass('Linux Password: ')
        pass_key_second = getpass.getpass('Re-enter Password: ')
        while (pass_key_first != pass_key_second):
            print("Password mismatch, please try again!")
            pass_key_first = getpass.getpass('Linux Password: ')
            pass_key_second = getpass.getpass('Re-enter Password: ')
        pass_key = pass_key_second
    print("")
    return user_name, pass_key, key_exist


def get_prompt_message_for_credentials(server_type):
    message = f"No {server_type} credentials supplied by user or specified in Migration Factory server secret attribute. Please enter credentials now."
    return message


def get_input_message_for_credentials(server_type):
    message = f"Do you wish to use the same credentials for all {server_type} servers in the job?, press [Y] or if you wish to be prompted per server [N]: "
    return message


# end of credential related functions ###############


# start of get servers functions ###############

def is_asset_associated_with_app(asset, app_id):
    return ('app_id' in asset and asset['app_id'] == app_id) or \
           ('app_ids' in asset and isinstance(asset['app_ids'], list) and app_id in asset['app_ids'])


def is_app_associated_with_wave(app, wave_id):
    return ('wave_id' in app and app['wave_id'] == wave_id) or \
           ('wave_ids' in app and isinstance(app['wave_ids'], list) and wave_id in app['wave_ids'])

def handle_client_error(error):
    sys_exit = False
    if ":" in str(error):
        err = ''
        msgs = str(error).split(":")[1:]
        for msg in msgs:
            err = err + msg
        msg = f"{ERROR_MSG_PREFIX} {err}"
        print(msg)
        sys_exit = True
    else:
        msg = f"{ERROR_MSG_PREFIX} {str(error)}"
        print(msg)
        sys_exit = True

    return sys_exit


# end of get servers related functions ###############

# start of user login related functions ###############

def get_login_data_for_user_pool(mf_config):
    try:
        using_secret = False
        secretsmanager_client = boto3.client(
            'secretsmanager', mf_config['Region'])
        mf_service_account = secretsmanager_client.get_secret_value(
            SecretId='MFServiceAccount-' + mf_config['UserPoolId'])
        mfauth = json.loads(mf_service_account['SecretString'])
        username = mfauth['username']
        password = mfauth['password']
        using_secret = True
    except botocore.exceptions.ClientError as e:
        print(e)
        if e.response['Error']['Code'] == 'ResourceNotFoundException' or e.response['Error'][
            'Code'] == 'AccessDeniedException':
            print("Service Account doesn't exist or access is denied to Secret, please enter username and password")
            default_user = ''
            if 'DefaultUser' in mf_config:
                default_user = mf_config['DefaultUser']
            username = input(
                "Factory Username [" + default_user + "]: ") or default_user
            password = getpass.getpass('Factory Password: ')

    return username, password, using_secret


def get_cmf_user_login_data(mf_config):
    username = ""
    password = ""
    using_secret = False
    if 'UserPoolId' in mf_config and 'Region' in mf_config:
        username, password, using_secret = \
            get_login_data_for_user_pool(mf_config)
    else:
        default_user = ""
        if 'DefaultUser' in mf_config:
            default_user = mf_config['DefaultUser']
        username = input(
            "Factory Username [" + default_user + "]: ") or default_user
        password = getpass.getpass('Factory Password: ')

    login_data = {'username': username, 'password': password}

    return login_data, username, using_secret


def factory_login_with_mfa(username, r_content, mf_config):
    if r_content.get('ChallengeName') == 'SMS_MFA':
        try:
            one_time_code = input("Please provide MFA One Time Code: ")
        except EOFError:
            print("", flush=True)
            print(f"{ERROR_MSG_PREFIX} MFA is enabled for the service account; this is not supported when used with "
                  f"CMF automation, if MFA is required, scripts must be run from the command line of the "
                  f"automation server.", flush=True)
            sys.exit(1)
        mfa_challenge_data = {
            'username': username, 'mfacode': one_time_code, 'session': r_content['Session']}
        r_mfa = factory_login_with_cognito_user_pool(
            mfa_challenge_data, mf_config)
        if r_mfa['statusCode'] == 200:
            print("Migration Factory : You have successfully logged in")
            print("")
            token = str(json.loads(r_mfa['body']))
            return token
        if r_mfa['statusCode'] == 502 or r_mfa['statusCode'] == 400:
            print(f"{ERROR_MSG_PREFIX} Incorrect MFA One Time Code provided....")
            sys.exit(1)


def validate_cmf_user_login(mf_config, login_data, username, using_secret, silent=False):
    try:
        r = factory_login_with_cognito_user_pool(login_data, mf_config)

        r_content = ''
        if 'body' in r:
            r_content = json.loads(r['body'])

        if r['statusCode'] == 200 and 'ChallengeName' in r_content:
            token = factory_login_with_mfa(username, r_content, mf_config)
        elif r['statusCode'] == 200:
            if not silent:
                print("Migration Factory : You have successfully logged in")
                print("")
            token = str(r_content)
            return token

        if r['statusCode'] == 502 or r['statusCode'] == 400:
            error_message = f"{ERROR_MSG_PREFIX} Incorrect username or password...."
            if using_secret:
                error_message = f"{ERROR_MSG_PREFIX} Incorrect username or password stored in Secrets Manager [MFServiceAccount-" + \
                                mf_config[
                                    'UserPoolId'] + "] in region " + mf_config['Region'] + "."
            print(error_message)
            sys.exit(1)
        else:
            print(r['text'])
            sys.exit()
    except requests.ConnectionError as e:
        logger.error(e)
        raise SystemExit(
            f"{ERROR_MSG_PREFIX} Connecting to the Login API failed, please check Login API in FactoryEndpoints.json file. "
            f"If the API endpoint is correct, please close cmd and open a new cmd to run the script again")


def get_login_response(mf_config, auth_data):
    try:
        body = auth_data
        client = boto3.client('cognito-idp', mf_config['Region'])
        response = {}
        userid = body['username']

        if 'mfacode' in body:
            # This is a response to MFA request on previous login attempt.
            mfacode = body['mfacode']
            session = body['session']
            response = client.respond_to_auth_challenge(
                ClientId=mf_config['UserPoolClientId'],
                ChallengeName='SMS_MFA',
                Session=session,
                ChallengeResponses={
                    'SMS_MFA_CODE': mfacode,
                    'USERNAME': userid
                }
            )
        else:
            password = body['password']
            response = client.initiate_auth(
                ClientId=mf_config['UserPoolClientId'],
                AuthFlow='USER_PASSWORD_AUTH',
                AuthParameters={
                    'USERNAME': userid,
                    'PASSWORD': password
                }
            )
    except Exception as e:
        if "NotAuthorizedException" in str(e) or "UserNotFoundException" in str(e):
            logger.error('Incorrect username or password: %s', userid)
            response = {
                'statusCode': 400,
                'body': 'Incorrect username or password'
            }
        else:
            logger.error(e)

    return response, userid


# Function provides authentication of user credentials to the CMF Cognito user pool directly rather than via the CMF
# /prod/login endpoint. This is required for instances using WAF.
def factory_login_with_cognito_user_pool(auth_data, mf_config):
    if 'UserPoolId' in mf_config and 'Region' in mf_config:
        response, userid = get_login_response(mf_config, auth_data)
        if 'AuthenticationResult' in response:
            logger.debug('User authenticated: %s', userid)
            return {
                'statusCode': 200,
                'body': json.dumps(response['AuthenticationResult']['IdToken'])
            }
        elif 'ChallengeName' in response:
            logger.debug('User challenge requested: %s', userid)
            return {
                'statusCode': 200,
                'body': json.dumps(response)
            }
    else:
        logger.error('Missing Cognito configuration in factory.json.')
        return {
            'statusCode': 200,
            'body': 'Missing Cognito configuration in factory.json.'
        }

# end of user login related functions ###############


def parse_list(value):
    if value:
        return value.split(',')

    return value


def parse_boolean(value):
    value = value.lower()

    if value in ["true", "yes", "y", "1", "t"]:
        return True
    elif value in ["false", "no", "n", "0", "f"]:
        return False

    return False